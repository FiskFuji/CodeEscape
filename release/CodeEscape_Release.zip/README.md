# CodeEscape
MLH Local Hack Day product. A productivity based tool aimed at helping students practice programming questions without the distraction of other desktop applications. Project Lead: Kirk Worley; Made by: Andy Kor, Arthur Diaz, Dallas Dituri, Jose Garcia, Kirk Worley.
